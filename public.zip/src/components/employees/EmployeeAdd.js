import React from "react";
import axios from "axios";
import './EmployeeAdd.css';
class EmployeeAdd extends React.Component {
    
    constructor(props) {
        super(props);
        this.state = {
            employeeItemData: {},
            idNum: 0
          };
       
      
       }
     
   
   async componentDidMount () { 
      
     const queryParams = new URLSearchParams(window.location.search);
     let  id = queryParams.get('id');
     this.setState({idNum: id});
      if(id) {
         await axios.get(`http://localhost:8000/employees/${id}`)
           .then(res => this.setState({ employeeItemData: res.data }));
      }
    }

 onSubmitHandler = async(event) => {
        event.preventDefault();
     
       const employee =  {
                name : event.target.name.value,
                email : event.target.email.value,
                address: event.target.address.value,
                phone: event.target.phone.value

            }
         
       if(this.state.idNum){
        employee.id = this.state.idNum;

        await axios.put(`http://localhost:8000/employees/${this.state.idNum}`, employee).then(() => window.location.href = "/employees")
       }else {
        await axios.post(`http://localhost:8000/employees`, employee).then(() => window.location.href = "/employees")
       } 
        
    }

render(){
    const readOnly = this.state.idNum > 0 ;
    return <div className="container-xl">
     <div className="table-responsive">
            <form onSubmit={this.onSubmitHandler}>
                 <div className="header">						
                     <h4 className="title">{this.state.idNum > 0 ? 'Edit' : 'Add'} Employee</h4>
                 </div>
                 <div className="body">					
                     <div className="form-group">
                         <label>Name</label>
                         <input type="text" className="form-control" required name="name" defaultValue ={this.state.employeeItemData.name}/>
                     </div>
                     <div className="form-group">
                         <label>Email</label>
                         <input type="email" className="form-control" required name="email" value={this.state.employeeItemData.email} readOnly={readOnly}/>
                     </div>
                     <div className="form-group">
                         <label>Address</label>
                         <textarea className="form-control" required name="address" defaultValue={this.state.employeeItemData.address}></textarea>
                     </div>
                     <div className="form-group">
                         <label>Phone</label>
                         <input type="text" className="form-control" required name="phone" defaultValue={this.state.employeeItemData.phone}/>
                     </div>					
                 </div>
                 <div className="footer">
                     <input type="button" className="btn btn-default" value="Cancel" onClick={(() =>  window.location.href = "/employees")}/>
                     <input type="submit" className="btn btn-success" value={this.state.idNum > 0 ? 'Edit' : 'Add'}/>
                 </div>
             </form>
     </div>
 </div>
 
}
}

export default EmployeeAdd;