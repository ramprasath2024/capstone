import { GET_PRODUCT_LIST } from "./actionTypes";

export const getProductList = (payload) => {{type: GET_PRODUCT_LIST, payload}};