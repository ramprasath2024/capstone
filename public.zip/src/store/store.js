import { applyMiddleware, createStore } from '@reduxjs/toolkit'
import{ compose} from 'redux';
import { productReducer } from './Reducer'
import thunk from 'redux-thunk'
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose;
const middlewares = thunk; //
export const store = createStore(productReducer,composeEnhancers(applyMiddleware(middlewares)))