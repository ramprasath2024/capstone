import React from "react";
import axios from "axios";
import {Link } from 'react-router-dom';
import './EmployeeList.css';
 class  EmployeeList extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        employees: [],
   
      };
  }

   componentDidMount() {
	this.getEmployees();
  
  }
deleteEmployeeItem(id) {
	if (window.confirm("Are you sure want to remove the item")) {
		axios.delete(`http://localhost:8000/employees/${id}`).then(() => this.getEmployees())
		
		
}
}

async getEmployees(){
	await axios.get(`http://localhost:8000/employees`)
    .then(res => this.setState({ employees: res.data }));
}

   
    render (){

      const {employees } = this.state;
     return <div className="container-xl">
	<div className="table-responsive">
		<div className="table-wrapper">
			<div className="table-title">
				<div className="row">
					<div className="col-sm-6">
						<h2>Manage <b>Employees</b></h2>
					</div>
					<div className="col-sm-6 btn-content">
          <Link to="/employees/add"  className="btn btn-success" data-toggle="modal"><i className="material-icons">&#xE147;</i> <span>Add New Employee</span></Link>
		
					</div>
				</div>
			</div>
			<table className="table table-striped table-hover">
				<thead>
					<tr>
						<th>
							<span className="custom-checkbox">
								<input type="checkbox" id="selectAll"/>
								<label htmlFor="selectAll"></label>
							</span>
						</th>
						<th>Name</th>
						<th>Email</th>
						<th>Address</th>
						<th>Phone</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
        {employees.map(employee =>
          <tr key={employee.id}>
						<td>
							<span className="custom-checkbox">
								<input type="checkbox" id="checkbox1" name="options[]" value="1"/>
								<label htmlFor="checkbox1"></label>
							</span>
						</td>
						<td>{employee.name}</td>
						<td>{employee.email}</td>
						<td>{employee.address}</td>
						<td>{employee.phone}</td>
						<td>
							<Link to={`/employees/add?id=${employee.id}`} className="edit" data-toggle="modal"><i className="material-icons" data-toggle="tooltip" title="Edit">&#xE254;</i></Link>
							<a href="#" onClick={() =>this.deleteEmployeeItem(employee?.id)} className="delete" data-toggle="modal"><i className="material-icons" data-toggle="tooltip" title="Delete">&#xE872;</i></a>
						</td>
            </tr>)}
          </tbody>
			</table>
			
		</div>
	</div>        
</div>
 }
      
    
  }

  export default EmployeeList;

  