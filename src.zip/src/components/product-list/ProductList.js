import React from "react";
import {NavLink  } from 'react-router-dom';
import axios from "axios";
import { connect } from "react-redux";
import { fetchProductList} from "../../store/Action";
import { store } from '../../store/store.js';
 class  ProductList extends React.Component {
     
 constructor(props) {
   super(props);
   this.state = {
    products: [],
    productFromCart: [],
    filterdProducts:  [],
    isFilterOn: false

  };
   
  }

  async  componentDidMount() {
    this.setState({isFilterOn: false});
    store.dispatch(fetchProductList());
    store.subscribe(() => {
      const state = store.getState();
      this.setState({ products: state.products })
  } )

  

 /*  store.dispatch(fetchCartList());
   store.subscribe(() => {
    const state = store.getState();
      this.setState({ productFromCart: state.products })
   })*/
  
  }

  async searchProduct(){
   const searchString = document.getElementById("productSearchFilter").value;
   searchString.length >0 ? this.setState({isFilterOn: true}) :this.setState({isFilterOn: false})
  const filterdProducts = this.state.products.filter((productItem) => productItem.name.search(searchString) >=0)
  this.setState({filterdProducts: filterdProducts})

  }

   clearSearchProduct(){
    this.setState({isFilterOn: false})
  }


 
   /* async  componentDidMount() {
   await axios.get(`http://localhost:8000/products`)
      .then(res => this.setState({ products: res.data }));

      await axios.get(`http://localhost:8000/cart`)
      .then(res => this.setState({ productFromCart: res.data }))
    } */

    async addToCart(product){
           await axios.get(`http://localhost:8000/cart`)
        .then(res => this.setState({ productFromCart: res.data }))
         product ={ ...product, quantity: 1};
      
            delete product['id'];
            axios.post(`http://localhost:8000/cart`,product);
             window.location.href = "/mycart";
    }
   
    render (){
        
    const  products  = this.state.isFilterOn ? this.state.filterdProducts:this.state.products;
      return <div className="container pt-4 pb-4">
    <h3>Mobiles & Accessories</h3>
    <div className="row"></div>
    <div className="row">
        <div className="col-lg-12">
        <div className="row">
    <div className="col-lg-8">
           </div>
          <div className="col-lg-4">
          <form>
        <div className="input-group col-lg-4">
          <input type="text" className="form-control" placeholder="Search" name="productSearchFilter" id="productSearchFilter"/>
          <div className="input-group-btn">
            <input type="button" value="  Filter" className="btn btn-primary btn-block" onClick={() => this.searchProduct()}/>
            <input type="reset" value=" Clear" className="btn btn-secondary btn-block" onClick={() => this.clearSearchProduct()}/>
           
           
          </div>
        </div>
      </form>
        </div>
        </div>
</div>
</div>
       

    <div className="row">
        <div className="col-lg-12">
            <div className="row">
      
             {products.map(product => <div className="col-lg-3 col-md-4 mb-6"   key={product.id}>
       
                    <div className="card h-100">
               
                    <NavLink  to={`/product-detail/${product.id}`}>
                            <img className="card-img-top" src={`${product.image}`} alt="" height="200px" />
                            </NavLink >
                        <div className="card-body">
                            <h4 className="card-title">
                            <NavLink  to={`/product-detail/${product.id}`}>{ product.name }</NavLink >
                            </h4>
                            <p className="card-text">{ product.description }</p>
                        </div>
                        {this.state.productFromCart.findIndex((item) => item.productId === product.productId)}
                        <div className="card-footer">
                           <button className={`btn btn-primary btn-block ${this.state.productFromCart.findIndex((item) => item.productId === product.productId) >=0? "disabled" : ""}`}  onClick={() => this.addToCart(product)}>
                              Add to Cart
                            </button>
                        </div>
                    </div>
                    
                </div>
                )}
                
            </div>
        </div>
    </div>
</div>


    }
      
    
  }

  // export default ProductList;


  const mapStateToProps = ({ data = {} }) => ({data});

  export default connect(mapStateToProps,{fetchProductList})(ProductList);