import React from "react";
import axios from "axios";
import {Link } from 'react-router-dom';
class  Header extends React.Component {
    constructor(props) {
      super(props);
      this.state = {
        cartItems: []
   };
    }
    async  componentDidMount() {
      
        await axios.get(`http://localhost:8000/cart`)
           .then(res => this.setState({ cartItems: res.data }));


         }
    render (){
return <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
<a className="navbar-brand" href="#">Shopping Cart<i className="fas fa-camera"></i></a>

<button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02"
    aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
</button>

<div className="collapse navbar-collapse" id="navbarTogglerDemo02">
    <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
    <li className="nav-item active">
        <Link to="employees"  className="badge badge-light">Employees</Link>
        </li>
        <li className="nav-item active">
        <Link to="products"  className="badge badge-light">Products</Link>
        </li>
        <li className="nav-item">
            <Link to="mycart" className="badge badge-light">
                Cart <span className="badge badge-light">{this.state.cartItems.length}</span>
            </Link>
        </li>
    </ul>
</div>
</nav>

    }
}

export default Header;