import React from "react";
import axios from "axios";

class  ProductDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            productItemData: [],
            productFromCart: [],
            productTocart: {},
            inCartItems : {}
       };
       
      
       }
     
      async  componentDidMount() {
        const url = document.location.pathname;
       let id = url.split("/")[2];
          await axios.get(`http://localhost:8000/products/${id}`)
           .then(res => this.setState({ productItemData: res.data }));

         await axios.get(`http://localhost:8000/cart`)
           .then(res => this.setState({ productFromCart: res.data|| {}}))

           this.setState({productTocart : this.state.productFromCart.filter((cartItem) => cartItem.productId === this.state.productItemData.productId)});
     
       }
         async addToCart(product){
          
              const quantitySelected = document.getElementById("orderQuantity").value;
              if(Object.keys(this.state.productTocart).length > 0){
                 this.setState({...this.state.productTocart, quantity: Number(quantitySelected )});
                          
                   axios.put(`http://localhost:8000/cart/${product.id}`, this.state.productTocart);
               
                 }else{
                    this.setState({
                        productTocart: {
                              ...this.state.productTocart,
                              quantity: Number(quantitySelected)
                        }
                    })
                    
                    delete product['id'];
                   product = {...product, quantity: Number(quantitySelected) }
                    axios.post(`http://localhost:8000/cart`,product);

                   }  
                   window.location.href = "/mycart";
            }
     
      render (){
        const { productItemData, productTocart} = this.state;
        return <div className="container" style={{paddingTop: "50px"}}>
        <div className="row">
            <div className="col-lg-4">
                <img className="img-fluid" src={`${productItemData.image}`} alt="" width="250px" height="100px"/>
            </div>
            <div className="col-lg-4">
                <h3 className="card-title">{productItemData.name}</h3>
              <p className="card-text">{productItemData.description}</p>
            </div>
            <div className="col-lg-4">
                <div className="card card-outline-secondary my-4">
                    <div className="card-header">
                        Cart Section
                    </div>
                    <div className="card-body">
                        <div className="input-group mb-3">
                            <input type="number" pattern="[0-9]*" min="1" max="5" id="orderQuantity" name="orderQuantity" className="form-control"/>
                            <div className="input-group-append">
                                <button className="btn btn-success" onClick={() => this.addToCart(productItemData)}>
                                    Add to Cart
                                </button>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
      }
    }

    export default ProductDetail;