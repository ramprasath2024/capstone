import React, { useState } from "react";
import axios from "axios";
import {NavLink} from 'react-router-dom';

class  CartDetail extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            cartItems: [],
            orderSubTotal : 0,
            shippingPrice: 0,
            cartOrderTotal: 0,
            quantitySelected: 0

       };
      
       }

    async cartProductDisplay(){
      
        let shippingPrice = 0;
       let cartOrderTotal = 0;
       let orderSubTotal = 0;
         await axios.get(`http://localhost:8000/cart`)
        .then(res => {
            
            this.setState({ cartItems: res.data }, () => {
                this.state.cartItems.forEach(element => {
                    orderSubTotal += Number(element.quantity) * element.price
                    this.setState({orderSubTotal : orderSubTotal});
                   
                   }); 
                   shippingPrice = orderSubTotal * 0.02;
                   cartOrderTotal = orderSubTotal + shippingPrice;
                   this.setState({cartOrderTotal : cartOrderTotal});
                   this.setState({shippingPrice : shippingPrice});
           
            })
           
        })
        

      
    }
     
      async  componentDidMount() {
        
        this.cartProductDisplay();

         }

         async addCartItemIncrement(product){
          
            let quantityUpdated = document.getElementById(`orderQuantity-${product.productId}`).value;
               let productTocart = this.state.cartItems.filter((cartItem) => cartItem.productId === product.productId)[0];
               if(Object.keys(productTocart).length > 0){
                  
                           productTocart = { ...productTocart, quantity: quantityUpdated  }
                   axios.put(`http://localhost:8000/cart/${product.id}`, productTocart).then(() =>this.cartProductDisplay().then(() =>this.forceUpdate()))
               
                 }else{
                    this.setState({
                        productTocart: {
                              ...productTocart,
                              quantity:quantityUpdated
                        }
                    })
                    delete product['id'];
                    axios.post(`http://localhost:8000/cart`,product).then (() =>   this.cartProductDisplay());
                   }  
                 
            }

           deleteCartItem(id){
           if (window.confirm("Are you sure want to remove the item")) {
                    axios.delete(`http://localhost:8000/cart/${id}`);
                 //   this.cartProductDisplay();
                    window.location.href = "/mycart";
            }
            }
        
    render (){
   
        const { cartItems } = this.state;
    if(cartItems.length > 0) {
         return  <div className="px-4 px-lg-0">
            <div className="container">
                <div className="row">
                    <div className="col-md-8 col-lg-8">
                        <div className="table-responsive">
                            <table className="table">
                                <thead>
                                    <tr>
                                        <th scope="col" className="border-0 bg-light">
                                            <div className="p-2 px-3 text-uppercase">Product</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light">
                                            <div className="py-2 text-uppercase">Price</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light">
                                            <div className="py-2 text-uppercase">Quantity</div>
                                        </th>
                                        <th scope="col" className="border-0 bg-light">
                                            <div className="py-2 text-uppercase">Remove</div>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {cartItems.map(cartItem => <tr key={cartItem.id}>
                                        <th className="border-0">
                                            <div className="p-2">
                                                <img src={cartItem?.image} alt="" width="70"
                                                    className="img-fluid rounded shadow-sm"/>
                                                    <div className="ml-3 d-inline-block align-middle">
                                                        <h5 className="mb-0"> <NavLink  to={`/product-detail/${cartItem.productId}`}
                                                            className="text-dark d-inline-block align-middle">{ cartItem?.name}</NavLink>
        
                                                        </h5><span
                                                            className="text-muted font-weight-normal font-italic d-block">{ cartItem?.description}</span>
                                                    </div>
                                                </div>
                                        </th>
                                        <td className="border-0 align-middle"><strong>{cartItem?.price}</strong>
                                        </td>
                                        <td className="border-0 align-middle">
                                            <strong>
                                                <input type="number"  min="1" max="100" className="form-control" id={`orderQuantity-${cartItem.productId}`}
                                                    defaultValue={cartItem?.quantity}
                                                    onChange={() =>this.addCartItemIncrement(cartItem)}/>
                                                </strong>
                                        </td>
                                        <td className="border-0 align-middle">
                                            <img src="/icons/remove.png" onClick={() =>this.deleteCartItem(cartItem?.id)}
                                                height="28px"/>
                                            </td>
                                    </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="col-md-4 col-lg-4">
                        <div className="bg-light px-4 py-4 text-uppercase font-weight-bold">Order summary </div>
                        <div className="p-4">
                            <div className="alert alert-info" role="alert">
                                Shipping and additional costs are calculated based on values you have entered.
                            </div>
                            <ul className="list-unstyled mb-4">
                                <li className="d-flex justify-content-between py-3 border-bottom">
                                    <strong className="text-muted">Order Subtotal</strong>
                                    <strong>{ this.state.orderSubTotal}</strong>
                                </li>
                                <li className="d-flex justify-content-between py-3 border-bottom">
                                    <strong className="text-muted">Shipping and handling</strong>
                                    <strong>{ this.state.shippingPrice }</strong>
                                </li>
                                <li className="d-flex justify-content-between py-3 border-bottom">
                                    <strong className="text-muted">Total</strong>
                                    <h5 className="font-weight-bold">{ this.state.cartOrderTotal}</h5>
                                </li>
                            </ul>
                            <span className="btn btn-success py-2 btn-block">Procceed to checkout</span>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    } else {
        return <div className="px-4 px-lg-0">
        <div className="container">
            <div className="row">
                <div className="col-md-12">
                    <div className="alert alert-primary" role="alert">
                        Your Cart is Empty! Please continue shopping!!
                    </div>
                </div>
            </div>
        </div>
    </div>
    }

    }
   
}

export default CartDetail;