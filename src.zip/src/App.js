import React, {Suspense, useEffect} from 'react';
import './App.css';
import { Route, Routes,  Outlet } from 'react-router-dom';
import ProductDetail from './components/product-detail/ProductDetail.js';
import CartDetail from './components/cart/CartDetail.js';
import EmployeeAdd from './components/employees/EmployeeAdd.js';
const LazyLoad = React.lazy(()=> import('./components/product-list/ProductList.js'));
const EmployeeLoad = React.lazy(() => import('./components/employees/EmployeeList.js'));
function App() {

 
 return (
    <div className="App">

<Outlet/>
     <Routes>
     <Route path="/" element={<LazyLoad/>}/>
     <Route path="/employees" element={
      
<Suspense fallback={<div>Loading....</div>}>


<EmployeeLoad/>

</Suspense>
} />

 <Route path="/products" element={

<Suspense fallback={<div>Loading....</div>}>

  <LazyLoad/>

</Suspense>
} />

<Route path="/product-detail/:id" element={<ProductDetail/>}/>
<Route path="/mycart" element={<CartDetail/>}/>
<Route path="/employees/add" element={<EmployeeAdd/>}/>
<Route path="/employees/edit/:id" element={<EmployeeAdd/>}/>
      </Routes>
    </div>
  );
}

export default App;

