import { GET_PRODUCT_DETAIL, GET_PRODUCT_LIST, GET_CART_LIST, GET_FAILURE } from "./actionTypes.js";
import axios from "axios";

export const getProductList  = (productList) => { 
 return {type: GET_PRODUCT_LIST, data: productList}

} 

export const getProductDetail = (productItem) => { return {type: GET_PRODUCT_DETAIL, data: productItem}}

export const getCartList = (productList) => { return {type: GET_CART_LIST, data: productList}} 

export const fetchFailure = (error) => {return {type: GET_FAILURE, data: error}}


export const fetchProductList = () => (dispatch) => {

  const request =  axios.get(`http://localhost:8000/products`);
   request.then(res =>  dispatch(getProductList(res.data)),
          error => dispatch(fetchFailure(error?.message))

)}

export const fetchProductItem = () => (id, dispatch) => {

    const request = axios.get(`http://localhost:8000/products/${id}`);
   request.then(res =>  dispatch(getProductDetail(res.data)),
   error => dispatch(fetchFailure(error.message))
)};


export const fetchCartList = () => (dispatch) => {

    const request = axios.get(`http://localhost:8000/cart`);
   request.then(res => dispatch(getCartList(res.data)),
   error => dispatch(fetchFailure(error.message))
)};


