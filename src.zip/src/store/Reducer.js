
import { GET_PRODUCT_DETAIL, GET_PRODUCT_LIST, GET_CART_LIST, GET_FAILURE } from "./actionTypes.js";

const initialState = {
    products: [],
    error: ''
}

export const productReducer = (state = initialState, action) =>{

    switch(action.type){
        case GET_PRODUCT_LIST:
        return  {...state, products: action.data}
           case GET_PRODUCT_DETAIL:
            return {...state, products: action.data}
         case GET_CART_LIST:
            return {...state, products: action.data}
        case GET_FAILURE:
            return {...state, products: [], error: action.error}
        default:
            return state;
    }

}